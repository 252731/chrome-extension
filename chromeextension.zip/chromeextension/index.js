const container = document.getElementById("container")
container.innerHTML= "<button onclick='buy()'> Buy! </button>"

function buy () {
    container.innerHTML += "<p>Thank you for buying! </p>"
   
}
// template strings/literals

const recipient = "James"

// Refactor the email string to use template strings
const email = `Hey ${recipient}! How is it going? Cheers Per`



const sender = "Barandyk"

const email1 = 
   
`Hey ${recipient}! 

    How is it going? 

        Cheers ${sender}`

console.log(email1)



let myLeads = `["www.awesomelead.com"]`

// 1. Turn the myLeads string into an array
myLeads = JSON.parse(myLeads)
// 2. Push a new value to the array
myLeads.push("www.lead2.com")
// 3. Turn the array into a string again
myLeads = JSON.stringify(myLeads)
// 4. Console.log the string using typeof to verify that it's a string
console.log(typeof myLeads)


console.log(  Boolean("")   ) // false
console.log(  Boolean("0")  ) // true
console.log(  Boolean(100)  ) //true
console.log(  Boolean(null) ) //false
console.log(  Boolean([0])  ) //true
console.log(  Boolean(-0)   ) //false



const welcomeEl = document.getElementById("welcome-el")

// Add the ability to choose the emoji as well!

function greetUser(greeting, name, emoji) {
    welcomeEl.textContent = `${greeting}, ${name} ${emoji}`
}
greetUser("Howdy", "James", "🔥")





//arguments 
function add(num1, num2) {
    return num1 + num2
}
//parameters
console.log( add(3, 4)   ) // should log 7
console.log( add(9, 102) ) // should log 111





function getFirst(arr) {
    return arr[0]
}
let firstCard = getFirst([10, 2, 5])
console.log(firstCard)
